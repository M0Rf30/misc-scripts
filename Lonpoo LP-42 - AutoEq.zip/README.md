# Lonpoo lp-42
See [usage instructions](https://github.com/jaakkopasanen/AutoEq#usage) for more options and info.

### Graphs
![](./Lonpoo%20lp-42.png)